# Codeita
[www.codeita.com](http://www.codeita.com)

* * *

You can use and modify Codeita under the [Creative Commons Attribution-NonCommercial 3.0 Unported (CC BY-NC 3.0)](http://creativecommons.org/licenses/by-nc/3.0/) license.

Codeita is a web-based text editor and web development suite. It's designed to run in browser.