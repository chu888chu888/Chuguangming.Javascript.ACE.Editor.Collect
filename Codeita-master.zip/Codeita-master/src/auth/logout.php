<?php
setcookie('x-codeita-user', '', time()-1, '/');
header("Location: ../../");
?>