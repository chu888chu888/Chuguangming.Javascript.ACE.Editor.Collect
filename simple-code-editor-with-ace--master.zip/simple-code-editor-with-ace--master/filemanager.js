function FileManager()
{
	var _self = this;
	this.$defaultFilename = "default-ace-file";
	this.files = {};
	this.currentFile = null;

	this.new = _newFile;
	this.save = _saveSessions;
	this.load = _loadFile;
	this.roll = _loadFiles;
	this.setFile = _setCurrentFile;
	this.getFiles = _getFiles;
	this.delete = _deleteFile;
	this.rename = _renameFile;

	// functions for file save, load...
	function _loadFiles()
	{
		if(_chkStorage())
		{
			var estr = localStorage.getItem(_self.$defaultFilename);
			if(estr === null) {
				_initFiles(); 
				_loadFileStorageEvent.detail.msg = "Files Load";
				_loadFileStorageEvent.detail.userObj = _getFiles();
				document.dispatchEvent(_loadFileStorageEvent);
				return false;}
			else{
				_self.files = JSON.parse(estr);
				// _self.currentFile = _self.files[_self.$defaultFilename];
				_setCurrentFile(_self.files[_self.$defaultFilename]);
				_loadFileStorageEvent.detail.msg = "Files Load";
				_loadFileStorageEvent.detail.userObj = _getFiles();
				document.dispatchEvent(_loadFileStorageEvent);
				return true;
			}
		}
		return false;
	}

	function _initFiles()
	{
		var defaultFile = _self.files[_self.$defaultFilename] ={};
		defaultFile.filename = _self.$defaultFilename;
		defaultFile.theme = 0;
		defaultFile.mode = 'javascipt';
		defaultFile.contents = "//Start coding...\n";

		// _self.$defaultFile = defaultFile;
		_setCurrentFile(defaultFile);

	}

	function _newFile()
	{
		var now = new Date();
		var newFilename = prompt('Enter new FileName', String(now.getTime()));
		var nameDuplicateCheck = _getFiles().indexOf(newFilename);
		if(nameDuplicateCheck < 0)
		{
			// new file
			_self.files[newFilename] = {};
			var newFile = _self.files[newFilename];
			newFile.filename = newFilename;
			newFile.theme = 0;
			newFile.mode = 'javascript';
			newFile.contents = '//Start coding...\n';

			_saveSessions();
			_setCurrentFile(newFile);
			_newFileEvent.detail.fileObj = newFile;
			document.dispatchEvent(_newFileEvent);
		}
	}

	function _loadFile(filename)
	{
		var files = _self.files;
		if(files.hasOwnProperty(filename))
		{
			_saveSessions();
			_setCurrentFile(files[filename]);
		}
	}

	function _deleteFile(filename)
	{
		var f = filename || _self.currentFile.filename;
		if(_self.files.hasOwnProperty(f))
		{
			if(f === _self.$defaultFilename) {
				alert('Can\'t Delete Default File.');
				return false;
			}
			var s = confirm('Delete this file?');
			if(s)
			{
				var delFile = _self.files[f];
				_self.files[f] = null;
				_updateFiles();
				_setCurrentFile(_self.files[_self.$defaultFilename]);
				_saveSessions();
				_deleteFileEvent.detail.fileObj = delFile;
				document.dispatchEvent(_deleteFileEvent);
				return true;
			}
			return false;
		}
		return false
	}

	function _renameFile(filename)
	{
		var f = filename || _self.currentFile.filename;
		if(!_self.files.hasOwnProperty(f)){return false;}
		var n = prompt('Enter new Name', f);
		if(f === n) {return false;}
		else {
			var newFile = _self.files[n] = {};
			var oldFile = _self.files[f];
			for(i in oldFile) {newFile[i] = oldFile[i]; }
			newFile.filename = n;
			_self.files[oldFile.filename] = null;
			_updateFiles();
			if(!filename){_setCurrentFile(newFile);}
			return true;
		}
	}

	function _saveSessions()
	{
		var files = _self.files;
		files[_self.currentFile.filename] = _self.currentFile;
		var estr = JSON.stringify(_self.files);
		if(_chkStorage())
		{
			localStorage.setItem(_self.$defaultFilename, estr);
			_saveFileEvent.detail.time = new Date();
			document.dispatchEvent(_saveFileEvent);
			return true;
		}
		return false;
	}

	function _setCurrentFile(fileObj)
	{
		var aFile = fileObj || _self.files[_self.$defaultFilename];
		var oldFile = _self.currentFile;
		_self.currentFile = aFile;
		_changeFileEvent.detail.newFileObj = aFile;
		_changeFileEvent.detail.oldFileObj = oldFile;
		document.dispatchEvent(_changeFileEvent);
	}

	function _getFiles()
	{
		var a = new Array();
		for(i in _self.files) {a.push(i); }
		return a;
	}

	function _updateFiles()
	{
		var newFiles = {};
		for(i in _self.files)
		{
			if(_self.files[i] != null){newFiles[i] = _self.files[i];}
		}
		_self.files = newFiles;
	}

	function _chkStorage()
	{
		if(window.localStorage){return true;}
		return false;
	}
	// class custom event
	var _loadFileStorageEvent = new CustomEvent('loadFromStorage', {bubbles:true, cancelBubble:true, detail:{msg:"", userObj:null}});
	var _loadFileEvent = new CustomEvent('loadFile', {bubbles:true, cancelBubble:true, detail:{msg:"", fileObj:null}});
	var _changeFileEvent = new CustomEvent('changeFile', {bubbles:true, cancelBubble:true, detail:{msg:"", newFileObj:null, oldFileObj:null}});
	var _saveFileEvent = new CustomEvent('saveFile', {bubbles:true, cancelBubble:true, detail:{msg:"", time:null}});
	var _newFileEvent = new CustomEvent('newFile', {bubbles:true, cancelBubble:true, detail:{msg:"", fileObj:null}});
	var _deleteFileEvent = new CustomEvent('deleteFile', {bubbles:true, cancelBubble:true, detail:{msg:"", fileObj:null}});
}


/*

function EditorInstance(wrapperID)
{

	var _self = this;
	this.key = _newKey();
	this.wrapperID = wrapperID || 'Editors';
	this.wrapper = _getWrapper();
	this.menuWrapper = _createMenuWrapper();
	this.$autosave = false;
	this.editor = null;
	this.fileManager = null;
	this.fileMenu = null;
	this.mode = 'javascript';
	this.saveFlag = null;
	this.theme = 0;
	this.add = _createEditor;
	this.allModes = _modes;
	this.allThemes = _themes;
	this.createFileMenu = _createFileMenu;
	this.initWithObj = _loadInfoObj;
	this.load = _load;
	this.save = _save;
	this.setMode = _setMode;
	this.setTheme = _setTheme;
	this.toggleAutosave = _toggleAutosave;
	this.getInfo = _getInfoObj;

	// this.themeMenu = _createThemeMenu();
	// this.modeMenu = _createModeMenu();



	//----------------- functions for create UI -------------------
	function _createEditor(){
		if(this.editor)
		{
			console.log('This Session already has an editor');
			return false;
		}

		var wrapper = _self.wrapper;
		// create theme selector
		// create mode selector
		// create editor div
		var dw = document.getElementById(_self.key);
		if(!dw)
		{
			dw = document.createElement('DIV');
			dw.id = _self.key;
			dw.className = 'editor';
			// #TODO : attach menus
			wrapper.appendChild(dw);
		}

		var _editor = ace.edit(_self.key);
		_editor.setTheme('ace/theme/ambiance');
		_editor.getSession().setMode('ace/mode/javascript');
		_self.editor = _editor;
		_createThemeMenu();
		_createModeMenu();
		_createButton('save',_save);
		//_createButton('New',_self.fileManager.new);
		return _editor;
	}

	function _createMenuWrapper()
	{
		var menuWrapperID = 'menu-wrapper-' + _self.key;
		var mw = document.getElementById(menuWrapperID);
		if(!mw)
		{
			mw = document.createElement('DIV');
			mw.id = menuWrapperID;
			mw.className = 'wrapper-menu';
		}
		mw.editorInstance = _self;
		// #TODO : create Save Button:

		_self.wrapper.appendChild(mw);
		return mw;
		_createSaveButton();
		_createButton(autosave, _toggleAutosave);

	}

	function _createThemeMenu()
	{
		var themeMenuId = 'menu-theme-' + _self.key;
		var tm = gg(themeMenuId);
		if(!tm)
		{
			tm = document.createElement('DIV');
			tm.id = themeMenuId;
			tm.className = 'menu-theme';
			var _select = document.createElement('SELECT');
			for(i=0;i<_themes.length;i++)
			{
				var opt = document.createElement('OPTION');
				opt.value = _themes[i];
				opt.innerHTML = _themes[i];
				_select.appendChild(opt);
			}
			_select.value = _self.theme;
			tm.appendChild(_select);
			_select.addEventListener('change',function(){_setTheme(_select.value); _save();});
		}
		_self.menuWrapper.appendChild(tm);
		_self.menuWrapper.themeMenu = _select;
	}

	function _createFileMenu(files)
	{
		var fm = _self.fileMenu;
		if(!fm)
		{
			fm = document.createElement('DIV');
			fm.className = 'menu-file';
			_self.fileMenu = fm;
		}
		else {fm.removeChild(fm.childNodes[0]) }

		var _select = document.createElement('SELECT');
		for(i=0;i<files.length;i++)
		{
			var opt = document.createElement('OPTION');
			opt.value = files[i];
			opt.innerHTML = files[i];
			_select.appendChild(opt);
		}
		_select.value = _self.fileManager.$currentSession.filename;
		_select.addEventListener('change', function(){_self.fileManager.loadfile(_select.value);});
		fm.appendChild(_select);
		_self.menuWrapper.appendChild(fm);
	}

	function _createModeMenu()
	{
		var modeMenuID = 'menu-mode-' + _self.key;
		var mm = gg(modeMenuID);
		if(!mm)
		{
			mm = document.createElement('DIV');
			mm.id = modeMenuID;
			mm.className = 'menu-mode';
			var _select = document.createElement('SELECT');
			for(i=0;i<_modes.length;i++)
			{
				var opt = document.createElement('OPTION');
				opt.value = _modes[i];
				opt.innerHTML = _modes[i];
				_select.appendChild(opt);
			}
			_select.value = _self.mode;
			mm.appendChild(_select);
		}
		_select.editorInstance = _self;
		mm.addEventListener('change', function(e){_setMode(_select.value);_save();});
		_self.menuWrapper.appendChild(mm);
		_self.menuWrapper.modeMenu = _select;
	}

	function _createSaveButton()
	{
		var mw = _self.menuWrapper;
		var saveButton = document.createElement('BUTTON');
		saveButton.innerHTML = 'SAVE';
		saveButton.addEventListener('click',_save);
		mw.appendChild(saveButton);
	}

	function _createButton(label, eHandler)
	{
		var mw = _self.menuWrapper;
		var someButton = document.createElement('BUTTON');
		someButton.innerHTML = label;
		someButton.addEventListener('click', eHandler);
		mw.appendChild(someButton);
	}


	function _updateMenu()
	{
		_self.menuWrapper.modeMenu.value = _self.mode;
		_self.menuWrapper.themeMenu.value = _self.theme;
		// if(_self.fileManager !=null) _createFileMenu(_self.fileManager.getFileList());
	}
	
	//----------------- functions for setting -------------------
	function _setTheme(t)
	{
		var _t = t;
		if(typeof(_t)=="number")
		{
			_self.editor.setTheme('ace/theme/' + _themes[_t]);
			_self.theme = _themes[_t];
		}
		else if (typeof(_t)=="string")
		{
			_self.editor.setTheme('ace/theme/'+ _t);
			_self.theme = _t;
		}
	}

	function _setMode(t)
	{
		var _t = t || 'javascript';
		if(typeof(_t) == "number")
		{
			_self.editor.getSession().setMode('ace/mode/' + _modes[_t]);
			_self.mode = _modes[_t];
		} else {
			_self.editor.getSession().setMode('ace/mode/' + _t);
			_self.mode = _t;
		}
	}

	function _getWrapper(){
		var w = gg(_self.wrapperID);
		if(!w)
		{
			w = document.createElement('DIV');
			w.id = _self.wrapperID;
			w.className = 'editors';
			document.body.appendChild(w);
		}	
		return w;
	}
	//----------------- functions for save and load -------------------
	function _getInfoObj()
	{
		var e = {};
		e.key = _self.key;
		e.theme = _self.theme;
		e.mode = _self.mode;
		e.contents = _self.editor.getValue();
		if(_self.fileManager != null) e.filename = _self.fileManager.$currentSession.filename;
		return e;
	}

	function _loadInfoObj(e)
	{
		_self.key = e.key || _newKey();
		_self.setTheme(e.theme);
		_self.setMode(e.mode);
		_self.editor.setValue(e.contents);
		_updateMenu();
	}

	function _save()
	{
		if(!_self.fileManager)
		{
			var e = _getInfoObj();
			var estr = JSON.stringify(e);
			localStorage.setItem('default-ace-file',estr);
			console.log('saved without filemanager');
			return true;
		}
		else
		{
			console.log("saved with filemanager");
			var e = _getInfoObj();
			_self.fileManager.$currentSession = _getInfoObj()
			_self.fileManager.save();
		}
	}

	function _load()
	{
		var estr = localStorage.getItem('default');
		if(estr == null) return false;
		var e = JSON.parse(estr);
		_loadInfoObj(e);
		_updateMenu();
		return true;
	}

	function _toggleAutosave()
	{
		if(!_self.saveFlag)
		{
			_self.$autosave = true;
			_self.saveFlag = setInterval(_save, 1000);		
		}else{
			_self.$autosave = false;
			clearInterval(_self.saveFlag);
			saveFlag = null;
		}

	}

	//-----------------functions-------------------
	function gg(edid) {return document.getElementById(gg); } 
	function _newKey()
	{
		var now = new Date();
		return String(now.getTime());
	}

	function _rand(max)
	{
		var e = max || _themes.length;
		return Math.random() * 10000 % max;
	}

	function _getDomain() {return document.location.href.match(/http[s]*:\/\/([a-zA-Z0-9\-\.]*)/)[1] }

	//-----------------Class Constants-------------------
	//
	var _themes = ["ambiance", "chaos", "chrome", "clouds", "clouds_midnight", "cobalt", "crimson_editor", "dawn", "dreamweaver", "eclipse", "github", "idle_fingers", "kr", "merbivore", "merbivore_soft", "mono_industrial", "monokai", "pastel_on_dark", "solarized_dark", "solarized_light", "textmate", "tomorrow", "tomorrow_night", "tomorrow_night_blue", "tomorrow_night_bright", "tomorrow_night_eighties", "twilight", "vibrant_ink", "xcode"];
	var _modes = ["abap", "asciidoc", "c9search", "c_cpp", "clojure", "coffee", "coldfusion", "csharp", "css", "curly", "dart", "diff", "django", "dot", "glsl", "golang", "groovy", "haml", "haxe", "html", "jade", "java", "javascript", "json", "jsp", "jsx", "latex", "less", "liquid", "lisp", "livescript", "lua", "luapage", "lucene", "makefile", "markdown", "objectivec", "ocaml", "perl", "pgsql", "php", "powershell", "python", "r", "rdoc", "rhtml", "ruby", "scad", "scala", "scheme", "scss", "sh", "sql", "stylus", "svg", "tcl", "tex", "text", "textile", "tm_snippet", "typescript", "vbscript", "xml", "xquery", "yaml"];

}



var $e;
var $d;
function init()
{
	$e = window.codeEditor = new EditorInstance();
	$d = $e.add();
	$m = new FileManager($e);
	$e.fileManager = $m;
	$m.load();
	// new button
	var bn = document.createElement('BUTTON');
	bn.innerHTML = 'NEW FILE';
	bn.addEventListener('click', function(){$m.new()});
	$e.menuWrapper.appendChild(bn);
	// delete button
	bn = document.createElement('BUTTON');
	bn.innerHTML = 'RENAME';
	bn.addEventListener('click', function(){$m.rename();});
	$e.menuWrapper.appendChild(bn);
	// $e.toggleAutosave();
	bn = document.createElement('BUTTON');
	bn.innerHTML = 'DELETE';
	bn.addEventListener('click', function(){$m.delete();});
	$e.menuWrapper.appendChild(bn);

}

document.addEventListener('DOMContentLoaded',init);
*/