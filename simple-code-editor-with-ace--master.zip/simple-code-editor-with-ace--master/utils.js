
var $e, $d, $m;

function updateMenu(){

	var menu = $e.$menu;
	while(menu.childNodes[0]) {menu.removeChild(menu.childNodes[0]); }
	var themes = $e.getThemes(); var modes = $e.getModes();
	var uis = [];




	var b1 = document.createElement('BUTTON');
	b1.innerHTML = 'Save';
	b1.addEventListener('click', function(){$e.save();});
	uis.push(b1);


	var s1 = document.createElement('SELECT');
	for (i=0;i<themes.length;i++)
	{
		var opt = document.createElement('OPTION');
		opt.value = themes[i];
		opt.innerHTML = themes[i];
		s1.appendChild(opt);
	}
	s1.value = $e.$theme;
	s1.addEventListener('change', function(e){$e.setTheme(e.target.value);});
	document.addEventListener('changeTheme', function(e){s1.value = e.detail.theme;});
	uis.push(s1);

	var s2 = document.createElement('SELECT');
	for (i=0;i<modes.length;i++)
	{
		var opt = document.createElement('OPTION');
		opt.value = modes[i];
		opt.innerHTML = modes[i];
		s2.appendChild(opt);
	}
	s2.value = $e.$mode;
	s2.addEventListener('change', function(e){$e.setMode(e.target.value);});
	document.addEventListener('changeMdoe', function(e){s2.value = e.detail.mode;});
	uis.push(s2);


	// if file manager exists
	var b2 = document.createElement('BUTTON');
	b2.innerHTML = "New File";
	var newClick = function()
	{
		$e.fileManager.new();
		$e.load();
		updateMenu();
	};
	b2.addEventListener('click', newClick);
	uis.push(b2);

	var b3 = document.createElement('BUTTON');
	b3.innerHTML = "Delete";
	var delClick = function()
	{
		$e.fileManager.delete();
		$e.load();
		updateMenu();
	};
	b3.addEventListener('click', delClick);
	uis.push(b3);

	var files = $m.getFiles();
	var s3 = document.createElement('SELECT');
	for (i=0;i<files.length;i++)
	{
		var opt = document.createElement('OPTION');
		opt.value = files[i];
		opt.innerHTML = files[i];
		s3.appendChild(opt);
	}
	s3.value = $m.currentFile.filename;
	s3.addEventListener('change', function(e){$m.setFile($m.files[e.target.value]); $e.load();});
	document.addEventListener('changeFile', function(e){s3.value = e.detail.newFileObj.filename;});
	uis.push(s3);


	// insert ui
	for(i=0;i<uis.length;i++)
	{
		menu.appendChild(uis[i]);
	}
}


function readyEditor()
{
	updateMenu();
	$e.roll()

}

function init()
{

	addEventListener('loadEditorObj', function(e){console.log(e.detail.obj);});
	addEventListener('newEditor',readyEditor)
	$e = new EditorInstance();
	$m = new FileManager();
	$m.roll();
	$e.setFileManager($m);
	$e.insert();
	$d = $e.editor;
}

document.addEventListener('DOMContentLoaded', init);
