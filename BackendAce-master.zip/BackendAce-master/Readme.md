Backend Ace
============================

Backend Ace is a standalone editor that you can put in your site's directory and then edit files in the site from the raw source code without FTP. Backend Ace is based off of Ace (https://github.com/ajaxorg/ace).