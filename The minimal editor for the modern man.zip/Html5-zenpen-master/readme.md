# ZenPen - The minimal editor for the modern man

Zenpen (http://zenpen.io) is a web app for writing minimally, and getting into the Zone.

All information is persistant locally, using HTML5 local storage.

##ZenPen's minimal interface
![ZenPen](http://i.imgur.com/gHLGRDR.png)

##Text styling
![Text Styling](http://i.imgur.com/D7l9pRD.png)
